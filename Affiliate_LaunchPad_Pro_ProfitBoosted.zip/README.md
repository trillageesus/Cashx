# Affiliate LaunchPad Pro

This is a lightweight, no-code-required affiliate link generator. Just open `index.html` to start earning. Built for maximum simplicity and conversions.

## Features
- Custom referral ID input
- Dynamic product linking
- Mobile-responsive UI
- One-click copy to clipboard
- GitHub Pages ready

## Deployment
1. Upload all files to a GitHub repo
2. Enable GitHub Pages from the Settings > Pages tab
3. Start earning: yoursite.github.io/affiliate-launchpad/

Built to grow your passive income. Happy launching!
