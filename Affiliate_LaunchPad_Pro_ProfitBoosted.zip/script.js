function generateLink() {
    const product = document.getElementById("product-select").value;
    const referralId = document.getElementById("referral-id").value.trim();
    const output = document.getElementById("affiliate-link-output");
    const copyInput = document.getElementById("copy-link");

    if (!referralId) {
        output.innerHTML = "<span style='color: red;'>Please enter your referral ID.</span>";
        return;
    }
    if (!product) {
        output.innerHTML = "<span style='color: red;'>Please select a product.</span>";
        return;
    }

    const link = `https://affiliatesite.com/${referralId}?product=${product}`;
    output.innerHTML = `Your link: <a href="${link}" target="_blank">${link}</a>`;
    copyInput.value = link;
    copyInput.hidden = false;
    showShareButtons(link);
}

function copyLink() {
    const copyInput = document.getElementById("copy-link");
    if (!copyInput.value) return;
    copyInput.select();
    copyInput.setSelectionRange(0, 99999);
    document.execCommand("copy");

    const toast = document.getElementById("toast");
    toast.className = "toast show";
    setTimeout(() => { toast.className = toast.className.replace("show", ""); }, 2500);
}

function joinNow() {
    window.location.href = "https://example.com/signup";
}

function updateDescription() {
    const descriptions = {
        fitness: "Promote the hottest fitness plan with high commissions.",
        finance: "Earn big with top-rated finance tools & credit offers.",
        tech: "Tech gadgets that convert — share & earn instantly!"
    };
    const product = document.getElementById("product-select").value;
    document.getElementById("product-description").innerText = descriptions[product] || "";
}

function showShareButtons(link) {
    const encoded = encodeURIComponent(link);
    const buttonsHTML = `
        <strong>Share this link:</strong><br/>
        <a href="https://wa.me/?text=${encoded}" target="_blank">WhatsApp</a>
        <a href="https://twitter.com/intent/tweet?url=${encoded}" target="_blank">Twitter</a>
        <a href="https://www.facebook.com/sharer/sharer.php?u=${encoded}" target="_blank">Facebook</a>
    `;
    document.getElementById("share-buttons").innerHTML = buttonsHTML;
}
