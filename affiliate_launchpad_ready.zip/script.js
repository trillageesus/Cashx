
function generateLink() {
    const product = document.getElementById("product-select").value;
    const link = `https://affiliatesite.com/ref123?product=${product}`;
    document.getElementById("affiliate-link-output").innerText = "Your link: " + link;
}

function joinNow() {
    alert("Redirecting to signup...");
    window.location.href = "https://example.com/signup";
}
